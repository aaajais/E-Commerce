// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: "AIzaSyCN4HTNvS5tgwRVVgPJK78KI9nBZeLFEqk",
    authDomain: "kid-zone-383a6.firebaseapp.com",
    projectId: "kid-zone-383a6",
    storageBucket: "kid-zone-383a6.appspot.com",
    messagingSenderId: "305592095767",
    appId: "1:305592095767:web:671d8a6e0d86cbfc623852"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
